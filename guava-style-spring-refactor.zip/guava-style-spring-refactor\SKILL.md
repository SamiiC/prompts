---
name: guava-style-spring-refactor
description: Refactor Java 25 Spring Boot microservice code with Guava-inspired engineering discipline: Google Java Style, bloatless code, small public APIs, explicit contracts, immutable boundaries, useful behavior-first unit/integration tests, and precise validation. Use for cleanup of controllers, services, DTOs, utility classes, helper classes, validation, exception handling, and tests when maintainability and organization are the goal.
---

# Guava-Style Spring Refactor

## Grounding

Use this skill to make a Spring Boot service cleaner in the spirit of Guava, not to turn it into a Guava clone.

For nontrivial refactors, read `references/guava-patterns.md` before editing. For test additions, test rewrites, or substantial simplification work, also read `references/testing-and-minimalism.md`. Prefer the target repository's established build, test, DI, validation, and formatting conventions unless they conflict with a clear quality rule below.

Do not copy Guava-specific compatibility annotations, package names, license headers, GWT/J2KT concerns, or library-only design choices into a Spring service.

## Workflow

1. Inspect the target classes, adjacent tests, build files, formatter configuration, package layout, and framework conventions.
2. Classify the code by layer: controller, service/use case, repository/client, domain/value type, DTO, mapper, validator, utility, test.
3. Identify the concrete quality problems before editing: mixed concerns, broad public API, mutable boundary data, implicit nullness, weak validation, static state, hidden I/O, duplicated logic, unclear names, brittle tests, or inconsistent error handling.
4. Choose the smallest design that solves the current real problem. Delete, inline, or narrow code before adding new classes, interfaces, builders, mappers, or configuration.
5. Refactor in small behavior-preserving slices. Avoid mass rewrites, package reshuffles, or renames unless they clearly reduce coupling or expose a cleaner domain boundary.
6. Preserve external API behavior unless the user explicitly asks for a breaking cleanup. For public endpoints, preserve status codes, response shapes, error codes, and validation behavior unless changed deliberately with tests.
7. Add, keep, or rewrite tests only when they prove behavior that a caller, user, operator, or maintainer relies on.
8. Run the narrowest relevant test set first, then broader tests when shared behavior changed.
9. Summarize the changed contracts, the tests run, code volume removed or added, and any residual risk.

## Bloatless Code Standard

- Code must earn its place. Add a type, method, interface, DTO, mapper, helper, test fixture, or test only when it serves a current use case better than the simpler alternative.
- Prefer no abstraction, then a private method, then a package-private helper, then a public abstraction. Move up that ladder only when the pressure is real.
- Start with the implementation you would be willing to keep. Do not scaffold broad architecture and plan to simplify later.
- Prefer direct, readable Java and existing Spring/JDK facilities over custom frameworks, reflection, generic processors, or "future-proof" extension points.
- Remove speculative code, unused options, empty layers, pass-through wrappers, one-method interfaces, generic `Manager`/`Processor`/`Helper` classes, and duplicated mapping code.
- Keep methods short because each method has one reason to exist, not because every branch must be extracted.
- If a new class or test cannot be justified in one concrete sentence, do not add it.
- Treat deletion and visibility reduction as first-class refactors.

## Coding Rules

- Keep public surface area small. Make classes, constructors, methods, and helpers package-private where possible.
- Prefer final fields, constructor injection, immutable inputs and outputs, and defensive copies at boundaries.
- Use records for simple request/response/value carriers when the project already uses Java records or there is no conflicting serialization convention.
- Keep controllers thin: request binding, validation, service call, response mapping. Move business rules out of controllers.
- Keep services as use-case orchestration. Avoid HTTP, servlet, response DTO, and persistence details in service APIs.
- Keep repositories and external clients behind service-owned interfaces only when there is a real alternate implementation, external contract, or test seam.
- Prefer named package-private helpers such as `PriceParser`, `OrderValidator`, or `InvoiceMapper` over broad `Utils` classes.
- If a static utility class is justified, make it `final`, give it a private constructor, keep it stateless and cohesive, and do not hide I/O, time, randomness, network calls, or Spring dependencies inside it.
- Validate arguments explicitly at non-HTTP boundaries. Use `Objects.requireNonNull`, existing project precondition helpers, or Guava `Preconditions` only if Guava is already an accepted dependency.
- Use Bean Validation for request DTOs and explicit domain checks for service/domain invariants.
- Distinguish bad caller/input, invalid state, not found, conflict, and downstream failures. Map web errors centrally with `@ControllerAdvice`.
- Avoid introducing a new abstraction only for a single caller unless it isolates a real volatile dependency or removes meaningful complexity.
- Avoid clever streams, reflection, global mutable state, static Spring access, and over-broad exception catches.
- Prefer fewer moving parts when two designs are equally clear. The smaller design wins.

## Formatting

Follow Google Java Style unless the repository has a stricter formatter:

- No wildcard imports.
- Static imports in one group, non-static imports in one group.
- Two-space indentation.
- Braces for `if`, `else`, `for`, `do`, and `while`, even for one-line bodies.
- One top-level class per file.
- Logical member ordering; keep overloads contiguous.
- Prefer 100-column wrapping and extract locals or helper methods when wrapping harms readability.
- Run the repository formatter instead of manually aligning code.

## Testing Rules

- Match the existing test stack. Do not add Truth, AssertJ, Mockito, Guava, or other libraries just for this style if the project does not already use them.
- Add or update tests for significant behavioral refactors, bug fixes, public contracts, risky branch logic, persistence queries, serialization, validation, error mapping, concurrency, time, money, permissions, and external integration boundaries.
- Do not add tests for trivial records, getters/setters, generated framework behavior, private methods through reflection, pass-through mocks, or classes whose behavior is already fully covered through a more meaningful public contract.
- A useful test fails for a plausible real defect. If it would still pass after the real behavior is broken, rewrite or delete it.
- Test observable behavior and contracts, not implementation choreography. Avoid tests that only verify "method X called method Y" unless that interaction is the external contract.
- Cover success, invalid input, null or empty input when allowed by the contract, boundaries, exact failure type/status, error body, ordering, idempotency, mutation/immutability, and important downstream failure behavior.
- Controller tests should verify HTTP status, validation behavior, authorization behavior when relevant, and serialized response/error bodies.
- Service tests should verify use-case behavior without HTTP details. Use real value objects and cheap fakes; mock only expensive or volatile boundaries.
- Integration tests should be sparse and valuable: Spring wiring, transaction behavior, repository queries, serialization/deserialization, security filters, real database behavior, or real HTTP-client contract behavior.
- Utility/helper tests should be exhaustive and table-driven when inputs are combinatorial.
- Prefer deterministic time, IDs, randomness, and ordering in tests. Inject `Clock`, deterministic ID generators, or existing project equivalents.
- Keep tests compact. Shared fixtures and builders are allowed only when they remove noise without hiding the important inputs and expected outputs.

## Output Expectations

When asked to refactor, first state the specific slice being changed. Then make the edits, run tests, and report:

- What code moved or became private/package-private.
- What contracts became explicit.
- What tests were added or updated.
- What low-value tests or bloated code were removed.
- What commands were run.
- What remains risky or intentionally unchanged.
