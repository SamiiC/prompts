# Behavior-First Tests and Bloatless Code

## Guava-Derived Principles

Guava's public docs and source imply a strict bar:

- A feature needs a real use case and should be a substantial improvement over the simplest workaround.
- Method and class semantics should be obvious from their signatures.
- Code should encourage good habits: fail fast, reject invalid inputs clearly, and leave room for future refactoring.
- Tests are assertions about the specification, not proof that implementation steps happened.
- Thorough testing does not mean bloated testing. It means high-signal coverage of contracts, boundaries, invariants, and failure modes.

Use these ideas in Spring services as follows: add less code, but make each remaining contract sharper and each test more likely to catch a real defect.

## Good Test Bar

Before adding or keeping any test, answer:

1. What behavior or contract does this protect?
2. What plausible bug would make this test fail?
3. Is this behavior better tested through a public endpoint/use case/helper contract instead of a private implementation detail?
4. Does the test add confidence not already provided by a nearby test?
5. Is the setup smaller than the behavior being tested?

If the answers are weak, do not add the test. If the test exists already, rewrite it or remove it as part of cleanup.

## Patterns Observed in Guava Tests

### Contract Matrices

Guava often covers a compact behavior matrix instead of creating a large object graph. `SplitterTest` checks simple delimiters, no delimiter, doubled delimiter, leading/trailing delimiter, empty input, trimming, and empty-string omission. The lesson: identify the dimensions of behavior, then test representative combinations directly.

For Spring code, use this for parsers, mappers, validators, policy checks, discount/tax/rate calculations, permission logic, and state transitions.

### Boundary and Failure Tests

Guava tests exact boundary behavior: invalid ranges, empty ranges, unbounded ranges, invalid cache builder settings, non-ASCII media types, overflow, and null handling. It frequently checks the exact exception type and sometimes the message when the message is part of the diagnosability contract.

For Spring code, test status codes, validation errors, conflict/not-found mapping, empty collections, missing optional fields, min/max numeric values, repeated commands, and illegal state transitions.

### Reference Implementations

`IntMathTest` cross-checks complex integer behavior against `BigIntegerMath` or mathematical reference behavior for broad candidate sets. This avoids testing the same algorithm against itself.

For Spring code, use a simple trusted reference only when the production logic is subtle: money rounding, date windows, scheduling, eligibility rules, pagination, sorting, or normalization. Keep the reference implementation inside the test simple enough to audit.

### Invariant Tests

Graph tests validate invariants after operations: degree relationships, edge/node consistency, mutable vs immutable view behavior, and copy equivalence.

For Spring code, assert invariants after a use case: persisted rows match emitted events, totals equal line sums, version numbers advance once, repeated cancellation is idempotent, response order is stable, and domain state remains internally consistent.

### Deterministic Time and Effects

Guava cache docs recommend injecting a `Ticker` to test timed eviction without waiting for wall-clock time.

For Spring code, inject `Clock`, deterministic ID generation, fake queues, fake clients, or test containers. Do not sleep in tests. Do not depend on current time, random IDs, thread scheduling, or database row ordering unless explicitly controlled.

### Reusable Contract Suites

Guava's testlib has reusable sanity tests for null handling, equality, serialization, and collection behavior. This is useful when the same contract applies to many implementations.

For Spring code, reusable test fixtures are justified for repeated endpoint error envelopes, repository contract suites, security permission matrices, or external client contract tests. Do not create test frameworks for one class.

## Unit Tests in a Spring Service

Use unit tests for pure behavior and use-case orchestration:

- Domain/value objects: invariants, parsing, normalization, equality if custom, boundaries.
- Validators/policies: allowed/denied matrices and reasons.
- Mappers: only when mapping has meaningful transformation or compatibility rules.
- Services: orchestration, transaction-relevant decisions, downstream failures, idempotency, state transitions, and emitted side effects.
- Helpers/utilities: exhaustive examples when the helper owns real logic.

Avoid unit tests for:

- Trivial records, DTOs, generated constructors, getters, setters, Lombok, or Jackson defaults.
- Private methods directly.
- Pass-through service methods whose behavior is already covered by a controller or integration test.
- Repository methods that need real query semantics; use repository integration tests instead.
- Framework annotations unless your code has custom behavior around them.

## Integration Tests in a Spring Service

Use integration tests sparingly for behavior that unit tests cannot honestly prove:

- `@WebMvcTest` or equivalent for controller contract: routing, validation, security, JSON shape, status codes, and error envelopes.
- `@DataJpaTest` or equivalent for real queries, entity mapping, constraints, optimistic locking, and transaction behavior.
- `@SpringBootTest` only when wiring, configuration, filters, serialization modules, transactions across layers, scheduling, messaging, or other framework integration is the actual risk.
- Testcontainers when behavior depends on the real database, broker, or infrastructure semantics.
- WireMock/mock web server when HTTP client serialization, headers, retries, error mapping, or contract handling is the risk.

Prefer a few high-value integration tests over a slow suite that boots the application for every branch.

## Test Anti-Patterns to Remove

- Tests that assert only non-null, no exception, or object construction.
- Tests that duplicate the implementation line-by-line.
- Tests that verify every mock interaction but assert no result.
- Tests that mock the class under test's own domain model instead of using real values.
- Tests that use `@SpringBootTest` for pure business logic.
- Tests that depend on random data without asserting a property.
- Tests whose names describe methods instead of behavior.
- Tests that are more complex than the production code path.
- Tests for every class just because the class exists.
- Large fixture builders where the meaningful input is hidden in defaults.

## Bloatless Code Philosophy

Apply this before writing code:

1. Is there a current use case, not a hypothetical future one?
2. Is the simplest direct implementation readable?
3. Can existing JDK, Spring, Bean Validation, persistence, or project helpers solve this cleanly?
4. Can a private method solve it before a helper class?
5. Can a package-private helper solve it before a public abstraction?
6. Can one concrete class solve it before an interface?
7. Can a value object or record replace a loose map, string bundle, or multiple primitive parameters?
8. Can deletion, inlining, or visibility reduction solve more than extraction?

The default answer to new architecture should be no. Add structure only after the current code proves it needs a name, boundary, or contract.

## AI Code Smells

Be suspicious of:

- `*Manager`, `*Processor`, `*Handler`, `*Helper`, `*Util`, `*Factory`, and `*Strategy` names without a precise domain meaning.
- Interfaces with one implementation and no volatile boundary.
- DTO-to-DTO mappers that copy fields without transformation.
- Builders for simple records or request DTOs.
- Abstract base services/controllers for unrelated features.
- Empty service layers that pass through to repositories.
- Generic response wrappers invented when the app already has an error/response convention.
- Reflection or annotation scanning for a fixed, small set of known behavior.
- Configuration properties for values that are not actually configurable.
- Tests that require many mocks to reach one assertion.

## Minimal Implementation Rules

- Prefer straightforward conditional logic over premature pattern usage.
- Prefer explicit names over generic reuse.
- Prefer local variables that explain a calculation over helper methods that hide it.
- Prefer immutable returns and defensive copies at boundaries.
- Keep overloads and variants limited to real callers.
- Keep branch count low by normalizing input early and failing fast.
- Replace repeated code only when the duplication is semantic, not merely visual.
- Allow small duplication in tests when it keeps each scenario clear.
- Avoid adding dependencies unless they remove substantial code or risk.
- Use comments only to explain non-obvious constraints, not to narrate code.

## Refactor Output Discipline

When finishing a refactor, report:

- Code removed, inlined, or made package-private.
- New code added and why it earns its place.
- Tests added, rewritten, or removed and the behavior each protects.
- Integration tests intentionally not added and why.
- Remaining risks.
