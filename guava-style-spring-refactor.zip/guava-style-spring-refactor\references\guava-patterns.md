# Guava Patterns Adapted for Spring Boot

## Important Limit

Guava is a general-purpose Java library, not a web microservice. Use it as a quality reference for API discipline, immutability, documentation, validation, formatting, lean implementation, and behavior-first tests. Do not imitate library-only concerns when working in a Spring Boot service.

For detailed test and code-volume rules, read `testing-and-minimalism.md`.

## Observed Guava Style

- Public APIs are treated as expensive. New API surface needs use cases and careful design before code.
- Features and abstractions need real utility. They should be meaningfully better than the simplest workaround.
- Packages are cohesive and domain-oriented, such as `base`, `collect`, `graph`, `cache`, `hash`, `io`, and `primitives`.
- Many implementation details are package-private. Public types are reserved for stable user-facing contracts.
- Value-oriented APIs use static factories such as `of`, `copyOf`, `create`, and `builder`.
- Immutable collections and defensive copies are common at boundaries.
- Constructors and methods validate inputs early with preconditions.
- Failure modes are precise: argument failure, state failure, index failure, unsupported operation, and null failure are distinct.
- Javadoc explains public contracts, failure modes, edge cases, performance notes, and usage warnings.
- Tests are detailed and behavior-focused, including success cases, failure cases, exact exception types, messages, nulls, boundaries, and combinatorial inputs.
- Tests are not merely numerous. They protect specifications, invariants, edge cases, and contracts.
- Formatting follows Google Java Style.
- Error Prone and nullness annotations appear where the build supports them.

## Spring Adaptation Table

| Guava pattern | Spring Boot adaptation | Avoid |
| --- | --- | --- |
| Careful public APIs | Treat REST endpoints, DTOs, service interfaces, events, and config properties as contracts | Adding endpoints, fields, public methods, or interfaces casually |
| Utility and ubiquity | Add code only when it clearly improves a current use case | Scaffolding future features, abstract factories, generic managers, or extension points |
| Cohesive packages | Prefer feature/domain packages with controllers, services, mappers, and validators close together | Large global `util`, `helper`, `common`, or `misc` dumping grounds |
| Package-private internals | Make mappers, validators, parsers, and algorithm helpers package-private when only local code uses them | Public classes because tests or DI make it convenient |
| Static factories/builders | Use named factories for non-obvious construction and builders only for genuinely complex values | Builders for every DTO or entity by default |
| Immutable boundaries | Use records, final fields, `List.copyOf`, `Map.copyOf`, unmodifiable views, and defensive copies | Returning mutable internal collections |
| Preconditions | Use Bean Validation at HTTP boundaries and explicit checks inside services/domain code | Relying only on database constraints or catching NPEs later |
| Precise failure types | Map validation, not found, conflict, downstream, and internal failures centrally | Throwing `RuntimeException` or returning null |
| Javadoc for contracts | Document public library-like service contracts and tricky behavior | Javadoc that repeats method names or obvious code |
| Exhaustive tests | Add focused tests around behavior, boundaries, invariants, and failure contracts before/with refactors | Snapshot-only, mock-only, class-exists, or happy-path-only tests |
| Google Java Style | Apply formatter and simple import/style rules | Manual alignment, wildcard imports, inconsistent wrapping |

## Layer Rules

### Controllers

- Keep mapping annotations, request binding, validation, authentication principal extraction, service invocation, and response mapping only.
- Use `@Valid` and Jakarta Bean Validation on request DTOs.
- Do not call repositories, clients, schedulers, or transactional implementation details directly.
- Do not contain business branching beyond request/response concerns.
- Prefer DTO records for stable JSON shapes when compatible with the project.
- Return `ResponseEntity` only when status, headers, or empty bodies need to vary.
- Keep error response creation in `@ControllerAdvice` or existing centralized error handling.

### Services

- Model each public method as a use case with a domain verb.
- Use constructor injection and final dependencies.
- Keep transaction boundaries at use-case level.
- Validate method parameters even when controllers also validate. Services are not controller-private helpers unless they are package-private.
- Keep HTTP types, request DTOs, response DTOs, `ResponseEntity`, servlet classes, and controller annotations out of service APIs.
- Return immutable values or copies when returning collections.
- Use small package-private collaborators to separate parsing, validation, mapping, and algorithms when a method grows mixed responsibilities.

### Domain and DTO Types

- Prefer simple records for immutable carriers.
- Keep domain names specific: `Money`, `CustomerId`, `BookingWindow`, `PaymentAttempt`, not vague `Data`, `Info`, or `Model`.
- Make null semantics explicit. Prefer absence as `Optional` at return boundaries when that is already project style; avoid `Optional` fields in DTOs unless the serializer and project convention support it.
- Use sealed interfaces only when the domain has a closed, meaningful set of variants and the project already accepts modern Java features.
- Keep persistence entities separate from public response DTOs.

### Utilities and Helpers

- Replace broad utility classes with focused helpers named after the concept they own.
- A static helper is acceptable for pure, stateless operations with no dependencies.
- Prefer injectable collaborators for time, randomness, ID generation, external calls, configuration, and expensive resources.
- Keep helper visibility package-private unless another package genuinely needs it.
- Make utility methods total and explicit: define behavior for null, empty, invalid, boundary, and overflow cases.

### Exceptions and Error Mapping

- Use `IllegalArgumentException` for invalid caller input inside non-web APIs.
- Use `IllegalStateException` for impossible or invalid internal state.
- Use domain-specific exceptions for not found, conflict, or business-rule failures when they cross layers.
- Convert exceptions to HTTP errors in one place.
- Preserve original causes for downstream failures.
- Do not log and rethrow unless the log adds context and will not create duplicate noise.

## Refactoring Checklist

1. Find the smallest behavior-preserving slice.
2. Lock behavior with existing tests or add characterization tests.
3. Narrow visibility before extracting abstractions.
4. Make inputs, outputs, and nullness explicit.
5. Split mixed controller/service/repository concerns.
6. Replace mutable boundary data with immutable copies.
7. Remove pass-through layers, unused abstractions, and speculative variants.
8. Rename vague classes and methods only when the new name reflects a real domain concept.
9. Extract package-private helpers for cohesive parsing, validation, mapping, or algorithms.
10. Delete low-value tests that only mirror implementation or assert framework behavior.
11. Run formatter and relevant tests.

## Review Heuristics

Flag these strongly:

- Controller contains business rules, repository calls, or transaction logic.
- Service method accepts or returns HTTP-specific types.
- Public helper exists only because a test needs access.
- `Utils` class has unrelated methods.
- Mutable lists/maps escape from a class.
- Null is an undocumented valid input or return.
- Broad catch block converts multiple failure modes into one vague error.
- A new interface has only one implementation and no clear volatile boundary.
- Tests only assert happy path behavior.
- Tests assert mocks or implementation calls without observable behavior.
- A new class, helper, interface, mapper, or fixture exists without a current use case.
- Formatting is manual rather than produced by the repository formatter.

## Source References

- Guava repository: https://github.com/google/guava
- Guava contributing guide: https://github.com/google/guava/blob/master/CONTRIBUTING.md
- Google Java Style Guide: https://google.github.io/styleguide/javaguide.html
- Guava philosophy: https://github.com/google/guava/wiki/PhilosophyExplained
- Guava conditional failures: https://github.com/google/guava/wiki/ConditionalFailuresExplained
- Guava cache testing note: https://github.com/google/guava/wiki/CachesExplained#testing-timed-eviction
- Representative Guava classes to inspect when needed:
  - `guava/src/com/google/common/base/Preconditions.java`
  - `guava/src/com/google/common/collect/ImmutableList.java`
  - `guava/src/com/google/common/collect/Range.java`
  - `guava/src/com/google/common/graph/AbstractBaseGraph.java`
  - `guava-tests/test/com/google/common/base/PreconditionsTest.java`
  - `guava-tests/test/com/google/common/base/SplitterTest.java`
  - `guava-tests/test/com/google/common/collect/RangeTest.java`
  - `guava-tests/test/com/google/common/math/IntMathTest.java`
  - `guava-tests/test/com/google/common/graph/AbstractGraphTest.java`
  - `guava-tests/test/com/google/common/net/MediaTypeTest.java`
